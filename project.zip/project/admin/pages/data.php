<?php
header('Content-Type: application/json');

$conn = mysqli_connect("localhost","root","","quizapp");

$sqlQuery = "SELECT student_id,marks FROM tbl_result_summary ORDER BY student_id";

$result = mysqli_query($conn,$sqlQuery);

$data = array();

foreach ($result as $row) {
	$data[] = $row;
	
}


mysqli_close($conn);

echo json_encode($data);
?>