<?php
// Database Connection file


define('DB_SERVER','localhost');

define('DB_USER','root');

define('DB_PASS' ,'');

define('DB_NAME', 'quizapp');

$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);

// Check connection

if (mysqli_connect_errno())

{

 echo "Failed to connect to MySQL: " . mysqli_connect_error();

}
?>


    <table border="1">
    <thead>
    
        <tr>
            <th>S.N.</th>
            <th>Name</th>
            <th>Date</th>
             <th>Mark</th>
            <th>Exam</th>
            <th>No. Of Times Malpracticed</th>
        </tr>
    </thead>
<?php
// File name
$filename="ResultSheet";
// Fetching data from data base
$query=mysqli_query($con,"select * from tbl_result_summary");
$cnt=1;
while ($row=mysqli_fetch_array($query)) {

?>

            <tr>
                <td><?php echo $cnt;  ?></td>
                <td><?php 
                $q=mysqli_query($con,"select first_name from tbl_student where student_id=" . $row['student_id']);
                while($r=mysqli_fetch_array($q) )
{
$s=$r['first_name'];
}
                echo $s;?></td>
                <td><?php echo $row['added_date'];?></td>
                <td><?php echo $row['marks'];?></td>
                <td><?php 
                $q1=mysqli_query($con,"select faculty from tbl_student where student_id=" . $row['student_id']);
                 while($r=mysqli_fetch_array($q1) )
{
$s=$r['faculty'];
}
                $q2=mysqli_query($con,"select faculty_name from tbl_faculty where faculty_id='$s'");
                while($r=mysqli_fetch_array($q2) )
{
$s=$r['faculty_name'];
}
                echo $s
                ?></td>
                <td><?php echo $row['total_violations'];?></td>
            </tr>
<?php 
$cnt++;
// Genrating Execel  filess
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=".$filename."-Report.xls");
header("Pragma: no-cache");
header("Expires: 0");

} ?>
         
    </table>

