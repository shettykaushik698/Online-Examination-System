<!DOCTYPE html>
<html>
<head>
<title>Result Chart</title>
<style type="text/css">
BODY {
    width: 550PX;
}

#chart-container {
    width: 100%;
    height: auto;
}
</style>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/Chart.min.js"></script>


</head>
<body>

    <div id="chart-container">
        <canvas id="graphCanvas"></canvas>
    </div>

    <script>
        $(document).ready(function () {
            showGraph();
        });


        function showGraph()
        {
            {
                $.post("data.php",
                function (data)
                {
                    console.log(data);
                     var name = [];
                    var marks = [];

                    for (var i in data) {
                       /* $conn = mysqli_connect("localhost","root","","quizapp");

                        $sqlQuery = "SELECT first_name FROM tbl_student WHERE student_id=" + data[i].student_id;
                        var fname=mysqli_query($conn,$sqlQuery);*/
                        name.push(data[i].student_id);
                        marks.push(data[i].marks);
                    }

                     var chartdata = {
                        labels: name,
                        datasets: [
                            {
                                label: 'Student Marks',
                                backgroundColor: '#49e2ff',
                                borderColor: '#46d5f1',
                                hoverBackgroundColor: '#CCCCCC',
                                hoverBorderColor: '#666666',
                                data: marks
                            }
                        ]
                    };

                    var graphTarget = $("#graphCanvas");

                    var barGraph = new Chart(graphTarget, {
                        type: 'bar',
                        data: chartdata
                    });
                });
            }
        }
        </script>           
        <br />
        <button style="background-color: #085be0; 
        color: #FFFFFF;
        padding:2%;
        border: none;
        cursor: pointer;" onclick="goBack()">Go Back</button>
        <script>
        function goBack() {
          window.history.back();
        }
        </script>
</body>
</html>