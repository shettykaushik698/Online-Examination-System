<?php 
    define('SITEURL','http://localhost:80/project/');
    define('LOCALHOST','localhost');
    define('USERNAME','root');
    define('PASSWORD','');
    define('DBNAME','quizapp');
?>