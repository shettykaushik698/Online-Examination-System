<!--Footer Starts Here-->
<style>
.foot1{
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: #449EFF;
   color: #FFFFFF;;
   text-align: center;
}
</style>
        <div class="foot1">
            <div class="wrapper">
                <p>
                    <a style="color: white;" href="" title="">OES</a> &copy; <?php echo date('Y'); ?>. All Rights Reserved.    
                    </a>.
                </p>
            </div>
        </div>
        <!--Footer Ends Here-->
</html>